    var config = {
        map: {
            '*': {
                'Magento_Checkout/template/minicart/content.html': 'Magento_Checkout/template/minicart/content.html',
                'Magento_Checkout/template/minicart/item/default.html': 'Magento_Checkout/template/minicart/item/default.html'
            }
        }
    };